const $ = (id) => document.getElementById(id);
const privateFields = ['revenue','cogs','otherIncome','operatingExpenses','financeCosts','tax'];
const governmentFields = ['govRevenue','grants','serviceIncome','govExpenses','depreciation','govFinance'];

function amount(id) {
  const value = Number($(id).value);
  return Number.isFinite(value) && value > 0 ? value : 0;
}
function currency(value) {
  const code = $('currency').value;
  try {
    return new Intl.NumberFormat('en-NG', {style:'currency', currency:code, minimumFractionDigits:2, maximumFractionDigits:2}).format(value);
  } catch {
    return `${code} ${value.toFixed(2)}`;
  }
}
function setStatus(message, error=false) {
  $('status').textContent = message;
  $('status').style.color = error ? '#b53c34' : 'var(--green)';
}
function getData() {
  const data = {
    orgName: $('orgName').value,
    orgType: $('orgType').value,
    period: $('period').value,
    currency: $('currency').value
  };
  [...privateFields, ...governmentFields].forEach(id => data[id] = $(id).value);
  return data;
}
function putData(data) {
  ['orgName','orgType','period','currency',...privateFields,...governmentFields].forEach(id => {
    if (data[id] !== undefined && $(id)) $(id).value = data[id];
  });
  updateType();
}
function updateType() {
  const gov = $('orgType').value === 'government';
  $('privateFields').classList.toggle('hidden', gov);
  $('governmentFields').classList.toggle('hidden', !gov);
  $('primaryLabel').textContent = gov ? 'Net surplus / (deficit)' : 'Net profit / (loss)';
  $('reportKind').textContent = gov ? 'Government / public-sector statement' : 'Private company profit or loss statement';
}
function row(label, value, options={}) {
  const tr = document.createElement('tr');
  if (options.total) tr.className = 'total-row';
  if (options.final) tr.className = 'final-row';
  const left = document.createElement('td');
  left.textContent = label;
  const right = document.createElement('td');
  right.className = 'amount';
  right.textContent = currency(value);
  tr.append(left,right);
  return tr;
}
function calculate() {
  updateType();
  const gov = $('orgType').value === 'government';
  let rows = [], income, expenses, result;
  if (!gov) {
    const revenue = amount('revenue'), cogs = amount('cogs'), other = amount('otherIncome');
    const operating = amount('operatingExpenses'), finance = amount('financeCosts'), tax = amount('tax');
    const gross = revenue - cogs;
    const operatingProfit = gross + other - operating;
    result = operatingProfit - finance - tax;
    income = revenue + other;
    expenses = cogs + operating + finance + tax;
    rows = [
      row('Sales / revenue', revenue),
      row('Less: cost of goods sold', -cogs),
      row('Gross profit / (loss)', gross, {total:true}),
      row('Add: other income', other),
      row('Less: operating expenses', -operating),
      row('Operating profit / (loss)', gross + other - operating, {total:true}),
      row('Less: finance costs', -finance),
      row('Profit / (loss) before tax', operatingProfit - finance, {total:true}),
      row('Less: income tax expense', -tax),
      row('NET PROFIT / (LOSS) FOR THE PERIOD', result, {final:true})
    ];
  } else {
    const revenue = amount('govRevenue'), grants = amount('grants'), services = amount('serviceIncome');
    const operating = amount('govExpenses'), depreciation = amount('depreciation'), finance = amount('govFinance');
    income = revenue + grants + services;
    expenses = operating + depreciation + finance;
    result = income - expenses;
    rows = [
      row('Tax and other revenue', revenue),
      row('Grants and transfers received', grants),
      row('Fees and service income', services),
      row('TOTAL REVENUE / INCOME', income, {total:true}),
      row('Less: employee and operating expenses', -operating),
      row('Less: depreciation / asset expenses', -depreciation),
      row('Less: finance costs', -finance),
      row('TOTAL EXPENSES', expenses, {total:true}),
      row('NET SURPLUS / (DEFICIT) FOR THE PERIOD', result, {final:true})
    ];
  }
  $('reportOrg').textContent = $('orgName').value.trim() || 'Organisation name not entered';
  $('reportPeriod').textContent = $('period').value.trim() || 'Reporting period not entered';
  $('totalIncome').textContent = currency(income);
  $('totalExpenses').textContent = currency(expenses);
  $('netResult').textContent = currency(result);
  $('netResult').classList.toggle('positive', result >= 0);
  $('netResult').classList.toggle('negative', result < 0);
  $('resultDescription').textContent = result >= 0 ? (gov ? 'Income exceeds expenses' : 'Income exceeds expenses') : 'Expenses exceed income';
  const tbody = $('statementRows');
  tbody.replaceChildren(...rows);
  setStatus('Statement calculated. Check the figures and classifications before use.');
}
$('orgType').addEventListener('change', () => { updateType(); });
$('calculateBtn').addEventListener('click', calculate);
$('saveBtn').addEventListener('click', () => {
  try {
    localStorage.setItem('profitLossAccountingApp', JSON.stringify(getData()));
    setStatus('Figures saved in this browser on this device.');
  } catch {
    setStatus('Could not save in this browser. Check browser storage settings.', true);
  }
});
$('loadBtn').addEventListener('click', () => {
  try {
    const saved = localStorage.getItem('profitLossAccountingApp');
    if (!saved) return setStatus('No saved figures were found in this browser.', true);
    putData(JSON.parse(saved));
    calculate();
    setStatus('Saved figures loaded.');
  } catch {
    setStatus('Saved figures could not be loaded.', true);
  }
});
$('resetBtn').addEventListener('click', () => {
  if (!confirm('Clear all entered figures? This will not delete previously saved figures.')) return;
  $('orgName').value = '';
  $('period').value = '';
  [...privateFields,...governmentFields].forEach(id => $(id).value = '0');
  $('orgType').value = 'private';
  $('currency').value = 'NGN';
  updateType();
  $('statementRows').replaceChildren(row('Click “Calculate statement” to prepare your report.', 0));
  $('statementRows').lastElementChild.cells[1].textContent = '—';
  $('reportOrg').textContent = 'Your organisation';
  $('reportPeriod').textContent = 'Reporting period not entered';
  $('totalIncome').textContent = currency(0);
  $('totalExpenses').textContent = currency(0);
  $('netResult').textContent = currency(0);
  setStatus('Form cleared.');
});
$('printBtn').addEventListener('click', () => window.print());
updateType();
